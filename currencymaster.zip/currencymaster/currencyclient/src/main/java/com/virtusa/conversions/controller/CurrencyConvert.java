package com.virtusa.conversions.controller;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.currencyservice.CurrencyConverterService;
import org.json.simple.parser.ParseException;

/**
 * Servlet implementation class CurrencyConvert
 */
@WebServlet("/CurrencyConvert")
public class CurrencyConvert extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CurrencyConvert() {
		super();
		// TODO Auto-generated constructor stub
	}

	/*
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 * response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int amount = Integer.parseInt(request.getParameter("amount"));
		String currencyType = request.getParameter("toCurrency");
		System.out.println(amount + " " + currencyType.substring(0, 3));
		CurrencyConverterService currencyConverterService = new CurrencyConverterService();
		Hashtable<String, Double> hashtable = null;
		double converted = 0;

		try {
			hashtable = currencyConverterService.getConversionRate();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Set<String> setOfCountries = hashtable.keySet();

		// for-each loop
		for (String key : setOfCountries) {

			if (key.equals(currencyType.split(" ")[0])) {

				System.out.println(amount * hashtable.get(key));
				converted = amount * hashtable.get(key);

			}

			// System.out.println("Code : " + key + "\t\t Currency : " +
			// hashtable.get(key));
		}
		request.setAttribute("rate", converted + "");

		request.getRequestDispatcher("/index.jsp").forward(request, response);

	}

}
