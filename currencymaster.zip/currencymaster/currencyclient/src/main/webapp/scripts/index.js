/**
 * 
 */
window.addEventListener('load',function()
		{
	var ajaxObject=null;
	try{
		ajaxObject=new XMLHttpRequest();
	}
	catch(e){
		try{
			ajaxObject=new ActiveXObject("Msxml2.XMLHTTP3.0");
		}

		catch(e){
			alert("browser is broken or ajax ");
		}
	}
	
	ajaxObject.open("get","https://restcountries.eu/rest/v2/all",true);
	ajaxObject.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
	ajaxObject.send(null);
	
	
	var selectRef=document.querySelector("select")
	
	ajaxObject.onreadystatechange=function()
	{
		if((ajaxObject.readyState==4) && (ajaxObject.status=200)){
			data=JSON.parse(ajaxObject.responseText);
			//console.log(data);
			
			for ( ele in data){
				console.log(data[ele]['name']);
				console.log(data[ele]['currencies'][0]['code']);
				option=document.createElement("option");
				
				//console.log(typeof(data[ele]['currencies'][0]['code']))
				
				textNode=document.createTextNode(data[ele]['currencies'][0]['code']+" - "+data[ele]['name']);
				option.appendChild(textNode);
				selectRef.appendChild(option);
			}
			
		}
	}
	
});