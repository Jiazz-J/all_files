package com.virtusa.webinsurance.controllers;

import java.awt.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sun.org.apache.bcel.internal.generic.NEW;
import com.virtusa.webinsurance.models.PolicyHolder;
import com.virtusa.webinsurance.validators.PolicyHolderValidator;

@Controller
public class PolicyHolderController {
	
	@Autowired
	private PolicyHolderValidator policyHolderValidator;

	@GetMapping("/loadpolicyholder")
	public ModelAndView loadPolicyHolder() {
		
		
		
		return new ModelAndView("addpolicyholder","policyHolder",new PolicyHolder());
		
		
		
	}
	
	@ModelAttribute("genderList")
	public ArrayList<String> genderList() {
		ArrayList<String> gendersList=new ArrayList<String>();
		gendersList.add("male");
		gendersList.add("female");
		return gendersList;
	}
	
	
	
	
	@PostMapping("/addpolicyholder")
	public String addPolicyHolder(@ModelAttribute("policyHolder") @Validated PolicyHolder policyHolderObject, BindingResult result) {
		
		String viewName=null;
		if(policyHolderObject!=null) {
			
			policyHolderValidator.validate(policyHolderObject, result);		
			if(result.hasErrors())
				viewName="addpolicyholder";
			else {
				
				viewName="home";
			}
		}
		return viewName;
		
		
		
	}
}
