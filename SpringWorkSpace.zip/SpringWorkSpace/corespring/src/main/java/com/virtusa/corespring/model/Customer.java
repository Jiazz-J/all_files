package com.virtusa.corespring.model;


import java.util.Date;
import java.util.List;

public class Customer extends Person{
	private int customerId;
	private List<String> assests;
	
	public List<String> getAssests() {
		return assests;
	}
	public void setAssests(List<String> assests) {
		this.assests = assests;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	private String customerName;
	private String email;
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	private Date doj;

}
