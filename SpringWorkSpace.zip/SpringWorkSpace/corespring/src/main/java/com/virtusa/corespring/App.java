package com.virtusa.corespring;

import java.util.Iterator;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.virtusa.corespring.model.Customer;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        Resource resource=new ClassPathResource("com/virtusa/corespring/resources/Customer-bean.xml");
        
        
		BeanFactory beanfactory=new XmlBeanFactory(resource);
        
        //IoC
        Customer customer=(Customer) beanfactory.getBean("customer");
        Customer customer1=(Customer) beanfactory.getBean("customer");
        
        
        
        System.out.println(customer.getCustomerId());
        System.out.println(customer.getName());
        System.out.println(customer.getEmail());
        System.out.println(customer.getDoj().toString());
		/*
		 * System.out.println(customer1.getCustomerId());
		 * System.out.println(customer1.getName());
		 * System.out.println(customer1.getEmail());
		 * System.out.println(customer1.getDoj().toString());
		 */
		
		  System.out.println(customer.getPermanentAddress().getCity());
		  System.out.println(customer.getPermanentAddress().getDoorNo());
		  System.out.println(customer.getPermanentAddress().getState());
		  System.out.println(customer.getPermanentAddress().getStreetName());
		
		  System.out.println(customer.getCommunicationAddress().getCity());
		  System.out.println(customer.getCommunicationAddress().getDoorNo());
		  System.out.println(customer.getCommunicationAddress().getState());
		  System.out.println(customer.getCommunicationAddress().getStreetName());
		  
		 
       for (String assest : customer1.getAssests()) {
    	   
    	   System.out.println(assest);
		
	}
         
		/*
		 * if(customer.equals(customer1)) { System.out.println("equal"); } else {
		 * System.out.println("prototype"); }
		 * 
		 * customer.setCustomerName("Bean");
		 * 
		 * System.out.println(customer1.getCustomerName());
		 * 
		 * 
		 * 
		 * 
		 */
        
        
        
        
        
        
        
        
        
        
        
    }
}
