package com.virtusa.corespring.model;

public class Person {
	
	private String name;
	private String email;
	private Long mobileNo;
	private Address permanentAddress;
	private Address communicationAddress;
	public Address getCommunicationAddress() {
		return communicationAddress;
	}
	public void setCommunicationAddress(Address communicationAddress) {
		this.communicationAddress = communicationAddress;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Address getPermanentAddress() {
		return permanentAddress;
	}
	public void setPermanentAddress(Address permanentAddress) {
		this.permanentAddress = permanentAddress;
	}
	
	

}
