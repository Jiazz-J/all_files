package com.virtusa.corespringannotaions;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.virtusa.corespringannotaions.models.Transaction;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        ApplicationContext context=new ClassPathXmlApplicationContext("com/virtusa/corespringannotaions/resources/application-bean.xml");
        Transaction transaction=(Transaction) context.getBean("transaction");
        System.out.println(transaction.getDot());
        
        
        System.out.println(transaction.getAccount().getAccountType());
        System.out.println(transaction.getAccount().getName());
        
        
        
        
    }
}
