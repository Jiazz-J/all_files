package com.virtusa.corespringannotaions.models;

import org.springframework.beans.factory.annotation.Autowired;

public class Account {
	
	
	
	public Account(String name, String accountType) {
		super();
		this.name = name;
		this.accountType = accountType;
	}


	private String name;
	private String accountType;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	

}
