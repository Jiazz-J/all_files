package com.virtusa.corespringannotaions.models;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

public class Transaction {

	
	private int transactionId;
	private long amount;
	@Autowired
	private Date dot;
	
	  @Autowired 
	  Account account;
	 
	
	
	
	
	
	
	@Autowired
	public Transaction(int transactionId, long amount, Date dot, Account account) {
		super();
		this.transactionId = transactionId;
		this.amount = amount;
		this.dot = dot;
		this.account = account;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public Date getDot() {
		return dot;
	}
	public void setDot(Date dot) {
		this.dot = dot;
	}
}
